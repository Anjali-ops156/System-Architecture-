# SalonEase — Salon & Spa Appointment & Management System

Design documentation for a salon appointment, billing and management platform.
Single salon, multiple stylists, three user roles.

> **Note:** this repository contains the **design documentation only** — there is no application code here yet.

---

## The problem

Small salons still take every booking on a phone and write it in a paper register. That costs the owner money in five specific ways:

| Current practice | What it costs |
|---|---|
| Bookings by phone and WhatsApp | Calls missed in the evening rush — the customer books elsewhere |
| No central record of who is free | Two customers promised the same stylist at 5 PM |
| No confirmation or reminder | 20–30% no-show rate; the chair earns nothing for that hour |
| Billing on paper slips | No record of what a customer spent or preferred |
| No reports | The owner cannot tell which service or stylist actually earns |

---

## Documents

| # | Document | What it covers |
|---|---|---|
| 01 | [Architecture Diagrams](diagrams.html) | Three drawings — layered system architecture, booking request flow, database relationship map |
| 02 | [Functional Specification](functional-spec.html) | All 39 screens, role permission matrix, frontend/backend design, 25-table schema |
| 03 | [High-Level Design](high-level-design.html) | C4 diagrams, sequence flows, NFRs, security architecture, 8 decision records |
| 04 | [Presentation & Viva Script](viva-script.html) | How to explain the project out loud, with likely questions and answers |

Open [`index.html`](index.html) for the landing page that links to all four.

---

## Architecture at a glance

Classic three-tier, with a stateless API so it can scale horizontally later.

```
Users (Customer · Staff · Admin)
        │  HTTPS
        ▼
FRONTEND   React 18 + Vite + Tailwind          → Vercel
        │  REST · JSON · Bearer JWT
        ▼
BACKEND    Node 20 + Express                   → Render
           middleware → controllers → services → repositories
        │  SQL over TLS
        ▼
DATABASE   PostgreSQL 16 · 25 tables           → Neon

EXTERNAL   Razorpay (test) · Resend · Cloudinary
```

The browser never reaches the database directly, and it never decides whether a payment succeeded — only a signature-verified webhook from the gateway does that.

---

## The hardest problem, and how it is solved

Two customers can open the booking page at the same moment, both see 5 PM as free, and both tap Confirm in the same second. This is prevented in **two independent layers**:

**1. Application lock.** The server does not trust the browser's slot list. It opens a transaction, takes a row lock on that stylist's bookings for that date, and re-checks. The first request commits and returns `201`. The second finds the slot taken, rolls back, and returns `409 Conflict` — the customer is returned to the time picker with a freshly loaded list.

**2. Database constraint.** A PostgreSQL GiST exclusion constraint:

```sql
EXCLUDE USING gist (
    staff_id WITH =,
    tsrange(booking_date + start_time, booking_date + end_time) WITH &&
) WHERE (status IN ('pending','confirmed','in_progress'))
```

This makes two overlapping bookings for one stylist physically impossible — even by direct SQL, even if the application code above it has a bug.

The lock gives a **good error message**. The constraint gives a **guarantee**.

---

## User roles

| Role | Can do |
|---|---|
| **Customer** | Browse, book for self, pay advance, view own bookings and invoices, review after a completed visit, redeem loyalty points |
| **Staff** | View own schedule, change appointment status, create walk-in bookings, generate bills, apply for leave |
| **Admin** | Everything above, plus manage services, staff, shifts, coupons, loyalty rules, refunds, moderation, settings and all reports |

Roles are enforced by an `authorize(role)` middleware on the server. Hiding a button in React is user experience, not security.

---

## Technology

**Frontend** React 18 · Vite · Tailwind CSS · React Router · React Hook Form + Zod · Recharts · FullCalendar
**Backend** Node.js 20 · Express · JWT · bcrypt · Zod · node-cron
**Database** PostgreSQL 16
**External** Razorpay (test mode) · Resend · Cloudinary
**Hosting** Vercel · Render · Neon — **total cost ₹0/month**

---

## Viewing these documents

Every file is self-contained HTML. Open any of them directly in a browser — no build step, no install.

Two of them (`functional-spec.html` and `high-level-design.html`) load the Mermaid library from a CDN to render their diagrams, and all files load fonts from Google Fonts, so **an internet connection is needed for those to look their best**. Without it the pages still work, with fallback fonts and unrendered diagram blocks.

`diagrams.html` uses hand-drawn SVG and needs no library at all.

### Publishing with GitHub Pages

1. Push this folder to a GitHub repository
2. Go to **Settings → Pages**
3. Under **Source**, choose `Deploy from a branch` → branch `main` → folder `/ (root)`
4. Save, wait about a minute

Your documentation will be live at `https://<your-username>.github.io/<repo-name>/`

The `.nojekyll` file is already included so GitHub serves the files as-is.

---

## Build plan

Thirteen milestones, each ending in something demonstrable, so there is never a half-working system with nothing to show.

| # | Milestone |
|---|---|
| 1 | Foundations — repo, database, migrations, seed data, skeletons |
| 2 | Auth and roles — JWT, middleware, route guards |
| 3 | Master data — services and staff CRUD, skills, shifts |
| 4 | Public site — home, services, stylists, contact |
| 5 | **Slots and booking** — the core algorithm and the booking wizard |
| 6 | Staff operations — schedule, status transitions, walk-ins |
| 7 | Billing — bills, GST, invoice numbering, offline payments |
| 8 | Online payments — gateway order, webhook, refunds |
| 9 | Notifications — templates, reminder cron, email log |
| 10 | Reviews — submission, rating rollup, moderation |
| 11 | Coupons and loyalty — validation, ledger, redemption |
| 12 | Dashboard and reports — KPIs, charts, exports |
| 13 | Polish and deploy — states, responsive, production deploy |

---

## Known limitations

- **Free-tier cold start.** The backend sleeps after 15 minutes idle, so the first request afterwards takes around 50 seconds. Mitigated with a cron ping every 10 minutes. This is a deliberate trade-off of zero-cost hosting.
- **Payments are test mode only.** Going live would require business verification, which is out of scope.
- **No automated end-to-end test suite yet.** Unit tests cover the slot and billing logic; the rest is a documented manual test script.

---

## Licence

Academic project. Free to read and learn from.
